#include <iostream>
#include <string>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <cppunit/extensions/HelperMacros.h>

using namespace std;

class Server : public CPPUNIT_NS::TestFixture
{
	  CPPUNIT_TEST_SUITE(Server );
	  CPPUNIT_TEST( getServer_port_UT );
	  CPPUNIT_TEST( getIp_addr_UT );
	  //CPPUNIT_TEST( validIp_addr_UT );
	 // CPPUNIT_TEST( setIp_addr_UT);
	  CPPUNIT_TEST(testServerClass);
	  CPPUNIT_TEST_SUITE_END();

	protected:
		int server_port;
		char* ip_addr;
	public:
		 Server() { 
			server_port = 69;
			ip_addr = "127.0.0.1";
		}

		void setUp();
              
		void setIp_addr(char* ip) { ip_addr = ip; }
		int getServer_port() { return server_port; }
		char* getIp_addr() { return ip_addr; }

			int validate_number(char *str){
                         while (*str) {
                          if(!isdigit(*str)){ //if the character is not a number, return
                          false;
                          return 0;
                              }
                          str++; //point to next character
                          }
                              return 1;
                              }
                  bool validIp_addr(char* ip)
	          {                            //check whether the IP is valid or not
                  int i, num, dots = 0;
                  char *ptr;
                  if (ip == NULL)
                  return 0;
                  ptr = strtok(ip, "."); //cut the string using dor delimiter
                 if (ptr == NULL)
                  return 0;
                  while (ptr) {
                   if (!validate_number(ptr)) //check whether the sub string is
                    // holding only number or not
                    return 0;
                   num = atoi(ptr); //convert substring to number
                   if (num >= 0 && num <= 255) {
                   ptr = strtok(NULL, "."); //cut the next part of the string
                  if (ptr != NULL)
                   dots++; //increase the dot count
                   } else
                     return 0;
                   }
                 if (dots != 3) //if the number of dots are not 3, return false
                  return 0;
                  return 1;
                  }
		


		void display()
		{
			cout<<"server port number: "<<server_port<<endl;
			cout<<"IP address: "<<ip_addr<<endl;
		}


protected:

	void getServer_port_UT();
	void getIp_addr_UT ();
	void validIp_addr_UT();
	void setIp_addr_UT();
	void testServerClass();
};
